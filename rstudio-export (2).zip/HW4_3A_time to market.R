# Load necessary libraries
library(dplyr)
library(readr)
library(tidyr)
library(archr)

# Enumerate decision factors
enumerate_sf(n = c(2), .did = 1)  # Portability
enumerate_sf(n = c(4), .did = 2)  # Stability
enumerate_sf(n = c(3), .did = 3)  # Mechanism
enumerate_sf(n = c(2), .did = 4)  # Workout tracking
enumerate_sf(n = c(2), .did = 5)  # Noise reduction
enumerate_sf(n = c(2), .did = 6)  # Modularity
enumerate_sf(n = c(4), .did = 7)  # Belt system
enumerate_partition(n = 5, k = 2, .did = 8)  # Assembly type


# Create a full decision grid
month_metrics <- expand_grid(
  d1 = enumerate_sf(n= c(2), .did = 1),
  d3 = enumerate_sf(n = c(3), .did = 3),
  d4 = enumerate_sf(n= c(2), .did = 4),
  d6 = enumerate_sf(n= c(2), .did = 6),
  d8 = enumerate_sf(n = c(2), .did = 8),
  d9 = enumerate_sf(n = c(3), .did = 9)
)


# Function to compute time to market
get_time <- function(d1,d3,d4,d6,d8,d9) {
  m1 <- case_when(d1 == 0 ~ 8, d1 == 1 ~ 7)
  m3 <- case_when(d3 == 0 ~ 3, d3 == 1 ~ 6, d3 == 2 ~ 5)
  m4 <- case_when(d4 == 0 ~ 1, d4 == 1 ~ 4)
  m6 <- case_when(d6 == 0 ~ 5, d6 == 1 ~ 2)
  m8 <- case_when(d8 == 0 ~ 2, d8 == 1 ~ 3)
  m9 <- case_when(
    d8 == 0 & d9 == 0 ~ 2 + 4,
    d8 == 0 & d9 == 1 ~ 2 + 3,
    d8 == 0 & d9 == 2 ~ 2 + 2,
    d8 == 1 & d9 == 0 ~ 3 + 4,
    d8 == 1 & d9 == 1 ~ 3 + 3,
    d8 == 1 & d9 == 2 ~ 3 + 2,
    TRUE ~ 0
  )
  # Time-to-Market = ∑ (Design & development time + Prototyping time + Testing time + Manufacturing set-up time + Production quality control time)
  
  # Total time to market (TTm) = Time-D1 + Time-D3 + Time-D4 + Time-D6 + Time-D8 
  
  return(m1+m3+m4+m6+m8+m9)
}

# Apply the cost function to the dataset
data <- month_metrics %>%
  mutate(months = get_time(d1,d3, d4,d6,d8,d9))
month_metrics
data
# Plot the cost distribution
hist(data$months, main = "Time to market", xlab = "months", col = "blue", border = "black")
