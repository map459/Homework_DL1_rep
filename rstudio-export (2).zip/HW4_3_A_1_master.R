
# Load necessary libraries
library(dplyr)
library(readr)
library(tidyr)
library(archr)

# Enumerate decision factors
enumerate_sf(n = c(2), .did = 1)  # Portability
enumerate_sf(n = c(4), .did = 2)  # Stability
enumerate_sf(n = c(3), .did = 3)  # Mechanism
enumerate_sf(n = c(2), .did = 4)  # Workout tracking
enumerate_sf(n = c(2), .did = 5)  # Noise reduction
enumerate_sf(n = c(2), .did = 6)  # Modularity
enumerate_sf(n = c(4), .did = 7)  # Belt system
enumerate_partition(n = 5, k = 2, .did = 8)  # Assembly type



# Create a full decision grid

cost_metrics <- expand_grid(
  d1 = enumerate_sf(n = c(2), .did = 1),
  d2 = enumerate_sf(n = c(4), .did = 2),
  d3 = enumerate_sf(n = c(3), .did = 3),
  d4 = enumerate_sf(n = c(2), .did = 4),
  d5 = enumerate_sf(n = c(2), .did = 5),
  d6 = enumerate_sf(n = c(2), .did = 6),
  d7 = enumerate_sf(n = c(4), .did = 7),
  d8 = enumerate_sf(n = c(2), .did = 8), 
  d9 = enumerate_sf(n = c(3), .did = 9)
)

# Function to compute manufacturing cost
# here we prepare cost function as per decision , for example 
# m1 = if the architecture is built with  decision 1 then the manufacturing cost = 15$ and if it is stationery it will cost 8$
# like wise all decisions are coded

get_cost <- function(d1,d2, d3,d4, d5, d6,d7,d8,d9) {
  m1 <- case_when(d1 == 0 ~ 15, d1 == 1 ~ 8)
  m2 <- case_when(d2 == 0 ~ 12, d2 == 1 ~ 6,d2 == 2 ~ 10,d2 == 3 ~ 10)
  m3 <- case_when(d3 == 0 ~ 10, d3 == 1 ~ 20, d3 == 2 ~ 18)
  m4 <- case_when(d4 == 0 ~ 2, d4 == 1 ~ 15)
  m5 <- case_when(d5 == 0 ~ 7, d5 == 1 ~ 9)
  m6 <- case_when(d6 == 0 ~ 10, d6 == 1 ~ 0)
  m7 <- case_when(d7 == 0 ~ 10,d7 == 1 ~ 20,d7 == 2 ~ 5 ,d7 == 3 ~ 10)
  m8 <- case_when(d8 == 0 ~ 8, d8 == 1 ~ 10)
  m9 <- case_when(
    d8 == 0 & d9 == 0 ~ 8 + 15,
    d8 == 0 & d9 == 1 ~ 8 + 10,
    d8 == 0 & d9 == 2 ~ 8 + 7,
    d8 == 1 & d9 == 0 ~ 10 + 15,
    d8 == 1 & d9 == 1 ~ 10 + 10,
    d8 == 1 & d9 == 2 ~ 10 + 7,
    TRUE ~ 0
  )
 # Total manufacturing cost per unit = Cost-D1 + Cost-D2 + Cost-D3 + Cost-D4 + Cost-D5 + Cost-D6 + Cost-D7 + Cost-D8 
  return(m1 + m2 + m3 +m4 + m5 + m6+m7+m8+m9)
}

# Apply the cost function to the dataset
data <- cost_metrics %>%
  mutate(cost = get_cost(d1,d2, d3,d4, d5, d6,d7,d8,d9))
cost_metrics
data

# Considering the value postioning if we choose the band of cost as 50 to 70 $ 

filtered_data <- data %>%
  filter(cost >= 50 & cost <= 70)

# View the result
print(filtered_data)

# Plot the cost distribution
hist(data$cost, main = "Cost Distribution", xlab = "Cost", col = "blue", border = "black")
