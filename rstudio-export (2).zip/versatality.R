
# Load necessary libraries
library(dplyr)
library(readr)
library(tidyr)
library(archr)

# Enumerate decision factors
enumerate_sf(n = c(2), .did = 1)  # Portability
enumerate_sf(n = c(4), .did = 2)  # Stability
enumerate_sf(n = c(3), .did = 3)  # Mechanism
enumerate_sf(n = c(2), .did = 4)  # Workout tracking
enumerate_sf(n = c(2), .did = 5)  # Noise reduction
enumerate_sf(n = c(2), .did = 6)  # Modularity
enumerate_sf(n = c(4), .did = 7)  # Belt system
enumerate_partition(n = 5, k = 2, .did = 8)  # Assembly type



# Create a full decision grid

versatility_metrics <- expand_grid(
 
  d2 = enumerate_sf(n = c(4), .did = 2),
  d3 = enumerate_sf(n = c(3), .did = 3),
  d4 = enumerate_sf(n = c(2), .did = 4),
  d6 = enumerate_sf(n = c(2), .did = 6),
  d7 = enumerate_sf(n = c(4), .did = 7),
 )

# Function to compute manufacturing cost
# here we prepare cost function as per decision , for example 
# m1 = if the architecture is built with  decision 1 then the manufacturing cost = 15$ and if it is stationery it will cost 8$
# like wise all decisions are coded

get_versatality <- function(d2, d3,d4,d6,d7) {
  
  m2 <- case_when(d2 == 0 ~ 2, d2 == 1 ~ 1,d2 == 2 ~ 3,d2 == 3 ~ 3)
  m3 <- case_when(d3 == 0 ~ 2, d3 == 1 ~ 3, d3 == 2 ~ 3)
  m4 <- case_when(d4 == 0 ~ 1, d4 == 1 ~ 4)
  m6 <- case_when(d6 == 0 ~ 3, d6 == 1 ~ 1)
  m7 <- case_when(d7 == 0 ~ 3,d7 == 1 ~ 3,d7 == 2 ~ 1,d7 == 3 ~ 1)
 
TRUE ~ 0
  
# V = V-D2 x V-D3 x V-D4 x V-D6 x V-D7
  return( m2 *m3 *m4 *m6*m7)
}

# Apply the cost function to the dataset
data <- versatility_metrics %>%
  mutate(versatility = get_versatality(d2, d3,d4,d6,d7))
versatility_metrics
data


# Plot the cost distribution
hist(data$versatility, main = "Versatility", xlab = "Versatality scale", col = "blue", border = "black")

