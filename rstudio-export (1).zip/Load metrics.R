# Load capacity - Performance 

# Load necessary libraries
library(dplyr)
library(readr)
library(tidyr)
library(archr)

# Enumerate decision factors
enumerate_sf(n = c(2), .did = 1)  # Portability
enumerate_sf(n = c(4), .did = 2)  # Stability
enumerate_sf(n = c(3), .did = 3)  # Mechanism
enumerate_sf(n = c(2), .did = 4)  # Workout tracking
enumerate_sf(n = c(2), .did = 5)  # Noise reduction
enumerate_sf(n = c(2), .did = 6)  # Modularity
enumerate_sf(n = c(4), .did = 7)  # Belt system
enumerate_partition(n = 5, k = 2, .did = 8)  # Assembly type



# Create a full decision grid

Load_metrics <- expand_grid(
 
 d2 = enumerate_sf(n = c(4), .did = 2),
 d3 = enumerate_sf(n = c(3), .did = 3),
 d7 = enumerate_sf(n = c(4), .did = 7),
 d8 = enumerate_sf(n = c(2), .did = 8), 
 d9 = enumerate_sf(n = c(3), .did = 9)
)


# Function to compute manufacturing cost
# here we prepare cost function as per decision , for example 
# m1 = if the architecture is built with  decision 1 then the manufacturing cost = 15$ and if it is stationery it will cost 8$
# like wise all decisions are coded

get_load <- function(d2, d3,d7,d8,d9) {
  m2 <- case_when(d2 == 0 ~ 15, d2 == 1 ~ 15,d2 == 2 ~ 12,d2 == 3 ~ 12)
  m3 <- case_when(d3 == 0 ~ 10, d3 == 1 ~ 13, d3 == 2 ~ 15)
  m7 <- case_when(d7 == 0 & d7 == 1 ~ 15,
                  d7 == 2 & d7 == 3 ~ 10,
                  TRUE ~ 0
  )
 
  m9 <- case_when(
    d8 == 0 & d9 == 0 ~ 7,
    d8 == 0 & d9 == 1 ~ 8,
    d8 == 0 & d9 == 2 ~ 6,
    d8 == 1 & d9 == 0 ~ 8.4,
    d8 == 1 & d9 == 1 ~ 9.6,
    d8 == 1 & d9 == 2 ~7.2,
    TRUE ~ 0
  )
  # Total manufacturing cost per unit = Cost-D1 + Cost-D2 + Cost-D3 + Cost-D4 + Cost-D5 + Cost-D6 + Cost-D7 + Cost-D8 
  return(m2 + m3+m7+m9)
}

# Apply the cost function to the dataset
data <- Load_metrics %>%
  mutate(Load = get_load(d2, d3,d7,d8,d9))
Load_metrics
data


# Plot the cost distribution
hist(data$Load, main = "Load capacity", xlab = "Load", col = "blue", border = "black")
