
# Load necessary libraries
library(dplyr)
library(readr)
library(tidyr)
library(archr)

# Enumerate decision factors
enumerate_sf(n = c(2), .did = 1)  # Portability
enumerate_sf(n = c(4), .did = 2)  # Stability
enumerate_sf(n = c(3), .did = 3)  # Mechanism
enumerate_sf(n = c(2), .did = 4)  # Workout tracking
enumerate_sf(n = c(2), .did = 5)  # Noise reduction
enumerate_sf(n = c(2), .did = 6)  # Modularity
enumerate_sf(n = c(4), .did = 7)  # Belt system
enumerate_partition(n = 5, k = 2, .did = 8)  # Assembly type

# Reliability=1 / (∑Failure Rate of Components × Usage Cycles)
# Failure rates are benchmarked basis which Reliability is calculated for 1 warranty cycle of 2 years

# Create a full decision grid
Reliability_metrics <- expand_grid(
  
  d2 = enumerate_sf(n = c(4), .did = 2),
  d3 = enumerate_sf(n = c(3), .did = 3),
  d5 = enumerate_sf(n = c(2), .did = 5),
  d6 = enumerate_sf(n = c(2), .did = 6),
  d8 = enumerate_sf(n = c(2), .did = 8), 
  d9 = enumerate_sf(n = c(3), .did = 9)
)



# Function to Reliability 
# each decision will have its own Reliability for example for when d2 == 0 , stand is 99% functional 

get_reliability <- function(d2, d3,d5,d6,d8,d9) {
 
  m2 <- case_when(d2 == 0 ~ 0.99, d2 == 1 ~ 0.98, d2 == 2 ~ 0.985 , d2 == 3 ~ 0.99)
  m3 <- case_when(d3 == 0 ~ 0.96, d3 == 1 ~ 0.98, d3 == 2 ~ 0.97)
  m5 <- case_when(d5 == 0 ~ 0.95, d5 == 1 ~ 0.99)
  m6 <- case_when(d6 == 0 ~ 0.95, d6 == 1 ~ 0.99)
  m8 <- case_when(d8 == 0 ~ 0.99, d8 == 1 ~ 0.98)
  
  m9 <- case_when(
    d8 == 0 & d9 == 0 ~ 0.99* 0.97,
    d8 == 0 & d9 == 1 ~ 0.99 * 0.98,
    d8 == 0 & d9 == 2 ~ 0.99 * 0.985,
    d8 == 1 & d9 == 0 ~ 0.98 *0.97,
    d8 == 1 & d9 == 1 ~ 0.98 *0.98,
    d8 == 1 & d9 == 2 ~ 0.98 *0.985,
    TRUE ~ 0
  )
  # All decisions are in series so multiplicative rule 
  
  return(m2*m3*m5*m6*m8*m9)
}

# Apply the Reliability function to the dataset
data <- Reliability_metrics %>%
  mutate(Reliability = get_reliability(d2,d3,d5,d6,d8,d9))

Reliability_metrics
data
# Plot the Reliability distribution
hist(data$Reliability, main = "System Reliability", xlab = "Reliability", col = "blue", border = "black")
filtered_data <- data %>%
  filter(Reliability >= 0.9 & Reliability <= 0.95)
# View the result
print(filtered_data)
