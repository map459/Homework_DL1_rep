
# Load necessary libraries
library(dplyr)
library(readr)
library(tidyr)
library(archr)

# Enumerate decision factors
enumerate_sf(n = c(2), .did = 1)  # Portability
enumerate_sf(n = c(4), .did = 2)  # Stability
enumerate_sf(n = c(3), .did = 3)  # Mechanism
enumerate_sf(n = c(2), .did = 4)  # Workout tracking
enumerate_sf(n = c(2), .did = 5)  # Noise reduction
enumerate_sf(n = c(2), .did = 6)  # Modularity
enumerate_sf(n = c(4), .did = 7)  # Belt system
enumerate_partition(n = 5, k = 2, .did = 8)  # Assembly type



# Create a full decision grid
durability_metrics <- expand_grid(
  d1 = enumerate_sf(n = c(2), .did = 1),
  d3 = enumerate_sf(n = c(3), .did = 3),
  d5 = enumerate_sf(n = c(2), .did = 5),
  d6 = enumerate_sf(n = c(2), .did = 6),
  d8 = enumerate_sf(n = c(2), .did = 8), 
  d9 = enumerate_sf(n = c(3), .did = 9)
)

# Function to compute Durability 

get_durability <- function(d1, d3,d5,d6,d8,d9) {
  m1 <- case_when(d1 == 0 ~ 0.48 * 1e6, d1 == 1 ~ 0.72* 1e6)
  m3 <- case_when(d3 == 0 ~ 0.48 * 1e6, d3 == 1 ~ 0.72* 1e6, d3 == 2 ~ 0.6* 1e6)
  m5 <- case_when(d5 == 0 ~ 0.72 * 1e6, d5 == 1 ~ 0.6* 1e6)
  m6 <- case_when(d6 == 0 ~ 0.72 * 1e6, d6 == 1 ~ 0.96 * 1e6)
  m8 <- case_when(d8 == 0 ~ 0.6 * 1e6, d8 == 1 ~ 0.72 * 1e6)
# For combination of decisions DUrability is calculated as - d8=1, d9=2 (1/ (1/720000 + 1/480000))
  m9 <- case_when(
    d8 == 0 & d9 == 0 ~ 0.26*1e6,
    d8 == 0 & d9 == 1 ~ 0.327*1e6,
    d8 == 0 & d9 == 2 ~0.26*1e6,
    d8 == 1 & d9 == 0 ~ 0.288*1e6,
    d8 == 1 & d9 == 1 ~ 0.36*1e6,
    d8 == 1 & d9 == 2 ~ 0.288*1e6,
    TRUE ~ 0
  )
 # Durability of system is summation of individual cycles of sub system  
  return(1/(1/m1 + 1/m3+1/m5 + 1/m6+1/m8+1/m9))
}

# Apply the function 
data <- durability_metrics %>%
  mutate(Durability = get_durability(d1, d3,d5, d6,d8,d9))
durability_metrics
data
# Plot the  distribution
hist(data$Durability, main = "Durability distribution", xlab = "Durability", col = "blue", border = "black")
