# Load necessary libraries
library(dplyr)
library(readr)
library(tidyr)
library(archr)

# Enumerate decision factors
enumerate_sf(n = c(2), .did = 1)  # Portability
enumerate_sf(n = c(4), .did = 2)  # Stability
enumerate_sf(n = c(3), .did = 3)  # Mechanism
enumerate_sf(n = c(2), .did = 4)  # Workout tracking
enumerate_sf(n = c(2), .did = 5)  # Noise reduction
enumerate_sf(n = c(2), .did = 6)  # Modularity
enumerate_sf(n = c(4), .did = 7)  # Belt system
enumerate_partition(n = 5, k = 2, .did = 8)  # Assembly type



# Create a full decision grid
Supplychain_metrics <- expand_grid(
  d1 = enumerate_sf(n=c(2), .did = 1),
  d3 = enumerate_sf(n = c(3), .did = 3),
  d5 = enumerate_sf(n = c(2), .did = 5),
  d6 = enumerate_sf(n = c(2), .did = 6),
  d7 = enumerate_sf(n = c(4), .did = 7),
  d8 = enumerate_sf(n = c(2), .did = 8), 
  d9 = enumerate_sf(n = c(3), .did = 9)
)

# Function to compute time to market
get_Supplytime <- function(d1,d3,d5,d6,d7,d8,d9) {
  m1 <- case_when(d1 == 0 ~ 7, d1 == 1 ~ 4)
  m3 <- case_when(d3 == 0 ~ 5, d3 == 1 ~ 9, d3 == 2 ~ 8)
  m5 <- case_when(d5 == 0 ~ 6, d5 == 1 ~ 7)
  m6 <- case_when(d6 == 0 ~ 7, d6 == 1 ~ 3)
  m7 <- case_when(d7 == 0 ~ 9,d7 == 1 ~ 9,d7 == 2 ~ 5 ,d7 == 3 ~ 5)
  m8 <- case_when(d8 == 0 ~ 5, d8 == 1 ~ 6)
  m9 <- case_when(
    d8 == 0 & d9 == 0 ~ 5 + 15,
    d8 == 0 & d9 == 1 ~ 5 + 10,
    d8 == 0 & d9 == 2 ~ 5 + 7,
    d8 == 1 & d9 == 0 ~ 6 + 15,
    d8 == 1 & d9 == 1 ~ 6 + 10,
    d8 == 1 & d9 == 2 ~ 6 + 7,
    TRUE ~ 0
  
  )
  # Supply Chain Risk = ∑ (Component Dependence × Supplier Lead Time) 
  
  # SCr-total = SCr-D1 + SCr-D3 + SCr-D5 + SCr-D6 + SCr-D7 + SCr-D8
  
  return(m1+m3+m5+m6+m7+m8+m9)
}

# Apply the cost function to the dataset
data <- Supplychain_metrics %>%
  mutate(supplychain = get_Supplytime(d1,d3,d5,d6,d7,d8,d9))
Supplychain_metrics
data
# Plot the cost distribution
hist(data$supplychain, main = "Supply chain risk", xlab = "scale", col = "blue", border = "black")
